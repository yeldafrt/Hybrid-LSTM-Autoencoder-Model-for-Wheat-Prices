"""
Table 10: Relationship Between Data Quantity and Prediction Uncertainty
========================================================================
This script analyzes how the amount of available data affects prediction
uncertainty across different wheat classes.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# Paths
DATA_PATH = "/home/ubuntu/upload/pasted_file_tZfhP8_processed_data.csv"
OUTPUT_PATH = "/home/ubuntu"

print("=" * 80)
print("TABLE 10: Data Quantity vs Prediction Uncertainty Analysis")
print("=" * 80)

# Load data
print("\n[1] Loading data...")
df = pd.read_csv(DATA_PATH)
print(f"   Total records: {len(df)}")

# Filter only wheat classes (BUĞDAY)
wheat_classes = df[df['SinifAdi'].str.contains('BUĞDAY', na=False)]['SinifAdi'].unique()
print(f"   Wheat classes found: {len(wheat_classes)}")

# Prepare features - use numeric columns only
feature_cols = ['TahminiMiktar', 'Rutubet', 'Hektolitre', 'Protein', 'SuneKimil', 
                'KusurluTaneler', 'Kalite_Skoru', 'Fiyat_Kalite_Orani', 'Fiyat_Trend',
                'Fiyat_MA7', 'Fiyat_Volatilite', 'Toplam_Kusur', 'Mevsim_Gostergesi', 'Hafta_No']

# Check which columns exist
available_features = [col for col in feature_cols if col in df.columns]
print(f"   Available features: {len(available_features)}")

target_col = 'BirimFiyati'

# Filter wheat data only
df_wheat = df[df['SinifAdi'].str.contains('BUĞDAY', na=False)].copy()
print(f"   Wheat records: {len(df_wheat)}")

# Analyze by wheat class
print("\n[2] Analyzing uncertainty by wheat class...")

results = []

for wheat_class in wheat_classes:
    class_data = df_wheat[df_wheat['SinifAdi'] == wheat_class].copy()
    n_records = len(class_data)
    
    if n_records < 50:  # Skip classes with too few records
        continue
    
    # Prepare data
    X = class_data[available_features].fillna(0)
    y = class_data[target_col].values
    
    # Skip if target has no variance
    if y.std() < 0.001:
        continue
    
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Simple train/test split (80/20)
    split_idx = int(len(X_scaled) * 0.8)
    X_train, X_test = X_scaled[:split_idx], X_scaled[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    if len(X_test) < 10:
        continue
    
    # Train simple ensemble (LR + RF)
    lr = LinearRegression()
    rf = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
    
    lr.fit(X_train, y_train)
    rf.fit(X_train, y_train)
    
    # Predictions
    lr_pred = lr.predict(X_test)
    rf_pred = rf.predict(X_test)
    ensemble_pred = 0.5 * lr_pred + 0.5 * rf_pred
    
    # Calculate metrics
    r2 = r2_score(y_test, ensemble_pred)
    mae = mean_absolute_error(y_test, ensemble_pred)
    rmse = np.sqrt(mean_squared_error(y_test, ensemble_pred))
    
    # Calculate prediction std (uncertainty proxy)
    pred_std = np.std(ensemble_pred - y_test)
    
    # Bootstrap for CI width
    n_bootstrap = 100
    bootstrap_maes = []
    for _ in range(n_bootstrap):
        indices = np.random.choice(len(y_test), size=len(y_test), replace=True)
        boot_mae = mean_absolute_error(y_test[indices], ensemble_pred[indices])
        bootstrap_maes.append(boot_mae)
    
    ci_width = np.percentile(bootstrap_maes, 97.5) - np.percentile(bootstrap_maes, 2.5)
    
    # Coefficient of variation
    cv = (pred_std / np.mean(y_test)) * 100 if np.mean(y_test) > 0 else 0
    
    results.append({
        'Wheat_Class': wheat_class,
        'N_Records': n_records,
        'Test_Size': len(y_test),
        'R2': r2,
        'MAE_TL': mae,
        'RMSE_TL': rmse,
        'Pred_Std_TL': pred_std,
        'CI_Width_TL': ci_width,
        'CV_Percent': cv
    })
    
    print(f"   {wheat_class[:40]}: N={n_records}, R²={r2:.4f}, MAE={mae:.4f}")

# Create results dataframe
results_df = pd.DataFrame(results)
results_df = results_df.sort_values('N_Records', ascending=False)

print("\n[3] Correlation Analysis: Data Quantity vs Uncertainty...")

# Calculate correlations
corr_n_mae = stats.pearsonr(results_df['N_Records'], results_df['MAE_TL'])
corr_n_ci = stats.pearsonr(results_df['N_Records'], results_df['CI_Width_TL'])
corr_n_cv = stats.pearsonr(results_df['N_Records'], results_df['CV_Percent'])
corr_n_r2 = stats.pearsonr(results_df['N_Records'], results_df['R2'])

print(f"   Correlation (N vs MAE):      r = {corr_n_mae[0]:.4f}, p = {corr_n_mae[1]:.4f}")
print(f"   Correlation (N vs CI Width): r = {corr_n_ci[0]:.4f}, p = {corr_n_ci[1]:.4f}")
print(f"   Correlation (N vs CV%):      r = {corr_n_cv[0]:.4f}, p = {corr_n_cv[1]:.4f}")
print(f"   Correlation (N vs R²):       r = {corr_n_r2[0]:.4f}, p = {corr_n_r2[1]:.4f}")

# Group by data quantity ranges
print("\n[4] Summary by Data Quantity Groups...")

def categorize_n(n):
    if n < 200:
        return 'Small (N<200)'
    elif n < 500:
        return 'Medium (200≤N<500)'
    elif n < 1000:
        return 'Large (500≤N<1000)'
    else:
        return 'Very Large (N≥1000)'

results_df['Data_Group'] = results_df['N_Records'].apply(categorize_n)

group_summary = results_df.groupby('Data_Group').agg({
    'N_Records': ['count', 'mean'],
    'R2': 'mean',
    'MAE_TL': 'mean',
    'CI_Width_TL': 'mean',
    'CV_Percent': 'mean'
}).round(4)

print(group_summary)

# Create summary table for paper
print("\n[5] Creating Table 10 for paper...")

# Simplified table with key classes
table10_data = []

# Group order
group_order = ['Very Large (N≥1000)', 'Large (500≤N<1000)', 'Medium (200≤N<500)', 'Small (N<200)']

for group in group_order:
    group_data = results_df[results_df['Data_Group'] == group]
    if len(group_data) > 0:
        table10_data.append({
            'Data_Quantity_Group': group,
            'N_Classes': len(group_data),
            'Avg_Records': int(group_data['N_Records'].mean()),
            'Avg_R2': group_data['R2'].mean(),
            'Avg_MAE_TL': group_data['MAE_TL'].mean(),
            'Avg_CI_Width_TL': group_data['CI_Width_TL'].mean(),
            'Avg_CV_Percent': group_data['CV_Percent'].mean()
        })

table10_df = pd.DataFrame(table10_data)

print("\n" + "=" * 80)
print("TABLE 10: Relationship Between Data Quantity and Prediction Uncertainty")
print("=" * 80)
print(table10_df.to_string(index=False))

# Save results
results_df.to_csv(f"{OUTPUT_PATH}/table10_detailed_results.csv", index=False)
table10_df.to_csv(f"{OUTPUT_PATH}/table10_data_quantity_uncertainty.csv", index=False)

# Save correlation summary
corr_summary = pd.DataFrame({
    'Relationship': ['N vs MAE', 'N vs CI Width', 'N vs CV%', 'N vs R²'],
    'Correlation_r': [corr_n_mae[0], corr_n_ci[0], corr_n_cv[0], corr_n_r2[0]],
    'P_Value': [corr_n_mae[1], corr_n_ci[1], corr_n_cv[1], corr_n_r2[1]],
    'Interpretation': [
        'Negative: More data → Lower error' if corr_n_mae[0] < 0 else 'Positive: More data → Higher error',
        'Negative: More data → Narrower CI' if corr_n_ci[0] < 0 else 'Positive: More data → Wider CI',
        'Negative: More data → Lower variability' if corr_n_cv[0] < 0 else 'Positive: More data → Higher variability',
        'Positive: More data → Better fit' if corr_n_r2[0] > 0 else 'Negative: More data → Worse fit'
    ]
})
corr_summary.to_csv(f"{OUTPUT_PATH}/table10_correlation_summary.csv", index=False)

print("\n" + "=" * 80)
print("CORRELATION SUMMARY")
print("=" * 80)
print(corr_summary.to_string(index=False))

print("\n" + "=" * 80)
print(f"Results saved to: {OUTPUT_PATH}/table10_*.csv")
print("=" * 80)
