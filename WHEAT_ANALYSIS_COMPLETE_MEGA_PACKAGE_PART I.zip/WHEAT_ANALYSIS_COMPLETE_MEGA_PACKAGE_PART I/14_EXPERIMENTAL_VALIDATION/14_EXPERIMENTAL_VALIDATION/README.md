# 14_EXPERIMENTAL_VALIDATION

This folder contains scripts for the experimental validation analyses presented in Tables 6, 7, and 8 of the manuscript.

## Scripts

### 1. table6_ensemble_weight_comparison.py
**Purpose:** Validates the R²-based ensemble weight assignment strategy by comparing it with alternative weighting schemes (Table 6).

**Output:** 
- `table6_ensemble_weight_comparison.csv`

**Usage:**
```bash
python3 table6_ensemble_weight_comparison.py
```

### 2. table7_anomaly_detection_contribution.py
**Purpose:** Quantifies the contribution of the autoencoder-based anomaly detection module by comparing prediction performance on normal versus anomalous records (Table 7).

**Output:** 
- `table7_anomaly_detection_contribution.csv`
- `table7_additional_metrics.csv`

**Usage:**
```bash
python3 table7_anomaly_detection_contribution.py
```

### 3. table8_mechanistic_explanation.py
**Purpose:** Provides a mechanistic explanation for the high prediction accuracy through feature-target correlation analysis and data leakage verification (Table 8).

**Output:** 
- `table8_mechanistic_explanation.csv`
- `table8_verification_summary.csv`

**Usage:**
```bash
python3 table8_mechanistic_explanation.py
```

## Requirements

- Python 3.8+
- numpy
- pandas
- scikit-learn
- joblib
- tensorflow 2.x (required for LSTM model)

## Notes

- Scripts should be run from the `14_EXPERIMENTAL_VALIDATION` directory
- All paths are relative to the `WHEAT_ANALYSIS_MEGA_PACKAGE` parent directory
- TensorFlow is required to load the LSTM model for full 4-model ensemble results
- Scripts use `compile=False` when loading LSTM model for compatibility with TensorFlow 2.x

## Expected Results

### Table 6: Ensemble Weight Comparison
| Strategy | LR | RF | SVR | LSTM | Test R² | Test MAE (TL) |
|----------|-----|-----|-----|------|---------|---------------|
| Equal Weights | 0.250 | 0.250 | 0.250 | 0.250 | 0.9937 | 0.1714 |
| R²-Based (Proposed) | 0.256 | 0.255 | 0.235 | 0.253 | 0.9943 | 0.1637 |

### Table 7: Anomaly Detection Contribution
| Dataset | N | MAE (TL) | RMSE (TL) |
|---------|---|----------|-----------|
| Complete Test Set | 7,604 | 0.1645 | 0.2015 |
| Normal Records Only | 7,214 | 0.1617 | 0.1954 |
| Anomalous Records Only | 390 | 0.2170 | 0.2919 |

- MAE Ratio (Anomaly/Normal): 1.34x (34% higher)
- RMSE Ratio (Anomaly/Normal): 1.49x (49% higher)
- High-Error Anomaly Rate: 14.7% (vs. baseline 5.1%)

### Table 8: Feature-Target Correlations
| Feature | Correlation (r) | Variance Explained (r²) |
|---------|-----------------|------------------------|
| Price_Quality_Ratio | 0.9821 | 96.44% |
| Price_Trend | 0.8001 | 64.02% |
| Hectolitre | −0.7012 | 49.17% |
