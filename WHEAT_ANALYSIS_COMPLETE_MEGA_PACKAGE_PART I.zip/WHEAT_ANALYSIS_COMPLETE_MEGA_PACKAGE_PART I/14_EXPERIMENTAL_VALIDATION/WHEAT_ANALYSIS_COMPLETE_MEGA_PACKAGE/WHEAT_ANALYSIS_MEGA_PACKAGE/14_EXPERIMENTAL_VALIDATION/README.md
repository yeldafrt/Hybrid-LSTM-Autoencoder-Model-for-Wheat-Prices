# 14_EXPERIMENTAL_VALIDATION

This folder contains scripts for the experimental validation analyses presented in Tables 6, 7, and 8 of the manuscript.

## Scripts

### 1. table6_ensemble_weight_comparison.py
**Purpose:** Validates the R²-based ensemble weight assignment strategy by comparing it with alternative weighting schemes (Table 6).

**Output:** 
- `table6_ensemble_weight_comparison.csv`

**Usage:**
```bash
python3 table6_ensemble_weight_comparison.py
```

### 2. table7_anomaly_detection_contribution.py
**Purpose:** Quantifies the contribution of the autoencoder-based anomaly detection module by comparing prediction performance on normal versus anomalous records (Table 7).

**Output:** 
- `table7_anomaly_detection_contribution.csv`
- `table7_additional_metrics.csv`

**Usage:**
```bash
python3 table7_anomaly_detection_contribution.py
```

### 3. table8_mechanistic_explanation.py
**Purpose:** Provides a mechanistic explanation for the high prediction accuracy through feature-target correlation analysis and data leakage verification (Table 8).

**Output:** 
- `table8_mechanistic_explanation.csv`
- `table8_verification_summary.csv`

**Usage:**
```bash
python3 table8_mechanistic_explanation.py
```

## Requirements

- Python 3.8+
- numpy
- pandas
- scikit-learn
- joblib
- tensorflow (optional, for LSTM model)

## Notes

- Scripts should be run from the `14_EXPERIMENTAL_VALIDATION` directory
- All paths are relative to the `WHEAT_ANALYSIS_MEGA_PACKAGE` parent directory
- If TensorFlow is not installed, scripts will run with 3 models (LR, RF, SVR) instead of 4
