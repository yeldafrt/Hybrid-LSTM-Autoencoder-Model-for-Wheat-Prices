"""
Ablation Study: Fiyat_Kalite_Orani Değişkeni Olmadan Model Performansı
======================================================================
Bu script, Fiyat_Kalite_Orani değişkenini çıkararak tüm modelleri
yeniden eğitir ve performansları karşılaştırır.
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings('ignore')

# TensorFlow/Keras imports
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
tf.get_logger().setLevel('ERROR')
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input, Attention, Concatenate, Flatten
from tensorflow.keras.callbacks import EarlyStopping

print("="*70)
print("ABLATION ANALİZİ: Fiyat_Kalite_Orani Değişkeni Olmadan")
print("="*70)

# Veri yükleme
BASE_PATH = "/home/ubuntu/ablation_analysis/WHEAT_ANALYSIS_COMPLETE_MEGA_PACKAGE/WHEAT_ANALYSIS_MEGA_PACKAGE"
df = pd.read_csv(f"{BASE_PATH}/01_ORIGINAL_DATA/processed_data.csv")

print(f"\nOrijinal veri şekli: {df.shape}")
print(f"Toplam özellik sayısı: {df.shape[1]}")

# Hedef değişken
target_col = 'BirimFiyati'

# Çıkarılacak sütunlar (tarih, hedef ve Fiyat_Kalite_Orani)
exclude_cols = ['FisTarih', 'BirimFiyati', 'Fiyat_Kalite_Orani']

# Özellik sütunları (Fiyat_Kalite_Orani OLMADAN)
feature_cols_without_fko = [col for col in df.columns if col not in exclude_cols]

print(f"\nFiyat_Kalite_Orani OLMADAN özellik sayısı: {len(feature_cols_without_fko)}")
print(f"Kullanılan özellikler: {feature_cols_without_fko}")

# Veri hazırlama
X = df[feature_cols_without_fko].copy()
y = df[target_col].copy()

# Kategorik değişkenleri kontrol et
print(f"\nVeri tipleri:")
print(X.dtypes.value_counts())

# Object tipindeki sütunları kaldır (zaten encoded versiyonları var)
object_cols = X.select_dtypes(include=['object']).columns.tolist()
if object_cols:
    print(f"\nKaldırılan object sütunlar: {object_cols}")
    X = X.drop(columns=object_cols)

print(f"\nSon özellik sayısı: {X.shape[1]}")

# Missing value kontrolü
print(f"\nMissing value sayısı: {X.isnull().sum().sum()}")
X = X.fillna(0)

# Train/Val/Test split (60/20/20)
n = len(X)
train_end = int(n * 0.6)
val_end = int(n * 0.8)

X_train = X.iloc[:train_end].values
X_val = X.iloc[train_end:val_end].values
X_test = X.iloc[val_end:].values

y_train = y.iloc[:train_end].values
y_val = y.iloc[train_end:val_end].values
y_test = y.iloc[val_end:].values

print(f"\nVeri bölünmesi:")
print(f"  Train: {X_train.shape[0]} örnek")
print(f"  Validation: {X_val.shape[0]} örnek")
print(f"  Test: {X_test.shape[0]} örnek")

# Normalizasyon
scaler_X = MinMaxScaler()
scaler_y = MinMaxScaler()

X_train_scaled = scaler_X.fit_transform(X_train)
X_val_scaled = scaler_X.transform(X_val)
X_test_scaled = scaler_X.transform(X_test)

y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
y_val_scaled = scaler_y.transform(y_val.reshape(-1, 1)).flatten()
y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).flatten()

# Sonuçları saklamak için
results = {}

def calculate_metrics(y_true, y_pred, model_name):
    """Performans metriklerini hesapla"""
    r2 = r2_score(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    
    # MAPE (sıfıra yakın değerleri filtrele)
    mask = y_true > 0.1
    if mask.sum() > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = np.nan
    
    return {'R2': r2, 'MAE': mae, 'RMSE': rmse, 'MAPE': mape}

# ============================================================
# 1. LINEAR REGRESSION
# ============================================================
print("\n" + "="*50)
print("1. LINEAR REGRESSION")
print("="*50)

lr_model = LinearRegression()
lr_model.fit(X_train_scaled, y_train_scaled)

# Tahminler
lr_pred_train = scaler_y.inverse_transform(lr_model.predict(X_train_scaled).reshape(-1, 1)).flatten()
lr_pred_val = scaler_y.inverse_transform(lr_model.predict(X_val_scaled).reshape(-1, 1)).flatten()
lr_pred_test = scaler_y.inverse_transform(lr_model.predict(X_test_scaled).reshape(-1, 1)).flatten()

results['Linear Regression'] = {
    'train': calculate_metrics(y_train, lr_pred_train, 'LR'),
    'val': calculate_metrics(y_val, lr_pred_val, 'LR'),
    'test': calculate_metrics(y_test, lr_pred_test, 'LR')
}

print(f"  Train R²: {results['Linear Regression']['train']['R2']:.4f}")
print(f"  Val R²:   {results['Linear Regression']['val']['R2']:.4f}")
print(f"  Test R²:  {results['Linear Regression']['test']['R2']:.4f}")

# ============================================================
# 2. RANDOM FOREST
# ============================================================
print("\n" + "="*50)
print("2. RANDOM FOREST")
print("="*50)

rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
rf_model.fit(X_train_scaled, y_train_scaled)

rf_pred_train = scaler_y.inverse_transform(rf_model.predict(X_train_scaled).reshape(-1, 1)).flatten()
rf_pred_val = scaler_y.inverse_transform(rf_model.predict(X_val_scaled).reshape(-1, 1)).flatten()
rf_pred_test = scaler_y.inverse_transform(rf_model.predict(X_test_scaled).reshape(-1, 1)).flatten()

results['Random Forest'] = {
    'train': calculate_metrics(y_train, rf_pred_train, 'RF'),
    'val': calculate_metrics(y_val, rf_pred_val, 'RF'),
    'test': calculate_metrics(y_test, rf_pred_test, 'RF')
}

print(f"  Train R²: {results['Random Forest']['train']['R2']:.4f}")
print(f"  Val R²:   {results['Random Forest']['val']['R2']:.4f}")
print(f"  Test R²:  {results['Random Forest']['test']['R2']:.4f}")

# ============================================================
# 3. SVR
# ============================================================
print("\n" + "="*50)
print("3. SVR (Support Vector Regression)")
print("="*50)

# SVR için veri boyutunu küçült (çok yavaş olabilir)
sample_size = min(10000, len(X_train_scaled))
indices = np.random.choice(len(X_train_scaled), sample_size, replace=False)

svr_model = SVR(kernel='rbf', C=1.0, gamma='scale')
svr_model.fit(X_train_scaled[indices], y_train_scaled[indices])

svr_pred_train = scaler_y.inverse_transform(svr_model.predict(X_train_scaled).reshape(-1, 1)).flatten()
svr_pred_val = scaler_y.inverse_transform(svr_model.predict(X_val_scaled).reshape(-1, 1)).flatten()
svr_pred_test = scaler_y.inverse_transform(svr_model.predict(X_test_scaled).reshape(-1, 1)).flatten()

results['SVR'] = {
    'train': calculate_metrics(y_train, svr_pred_train, 'SVR'),
    'val': calculate_metrics(y_val, svr_pred_val, 'SVR'),
    'test': calculate_metrics(y_test, svr_pred_test, 'SVR')
}

print(f"  Train R²: {results['SVR']['train']['R2']:.4f}")
print(f"  Val R²:   {results['SVR']['val']['R2']:.4f}")
print(f"  Test R²:  {results['SVR']['test']['R2']:.4f}")

# ============================================================
# 4. LSTM + ATTENTION
# ============================================================
print("\n" + "="*50)
print("4. LSTM + ATTENTION")
print("="*50)

# LSTM için veriyi reshape et
n_features = X_train_scaled.shape[1]
X_train_lstm = X_train_scaled.reshape(-1, 1, n_features)
X_val_lstm = X_val_scaled.reshape(-1, 1, n_features)
X_test_lstm = X_test_scaled.reshape(-1, 1, n_features)

# LSTM + Attention modeli
def build_lstm_attention_model(n_features):
    inputs = Input(shape=(1, n_features))
    
    # LSTM layers
    lstm1 = LSTM(64, return_sequences=True)(inputs)
    lstm2 = LSTM(32, return_sequences=True)(lstm1)
    
    # Simple attention (using Dense layer as attention weights)
    attention_weights = Dense(1, activation='tanh')(lstm2)
    attention_weights = tf.nn.softmax(attention_weights, axis=1)
    context = tf.reduce_sum(lstm2 * attention_weights, axis=1)
    
    # Output
    output = Dense(1)(context)
    
    model = Model(inputs=inputs, outputs=output)
    model.compile(optimizer='adam', loss='mse')
    return model

lstm_model = build_lstm_attention_model(n_features)

early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

print("  LSTM modeli eğitiliyor...")
history = lstm_model.fit(
    X_train_lstm, y_train_scaled,
    validation_data=(X_val_lstm, y_val_scaled),
    epochs=100,
    batch_size=32,
    callbacks=[early_stop],
    verbose=0
)

lstm_pred_train = scaler_y.inverse_transform(lstm_model.predict(X_train_lstm, verbose=0).reshape(-1, 1)).flatten()
lstm_pred_val = scaler_y.inverse_transform(lstm_model.predict(X_val_lstm, verbose=0).reshape(-1, 1)).flatten()
lstm_pred_test = scaler_y.inverse_transform(lstm_model.predict(X_test_lstm, verbose=0).reshape(-1, 1)).flatten()

results['LSTM + Attention'] = {
    'train': calculate_metrics(y_train, lstm_pred_train, 'LSTM'),
    'val': calculate_metrics(y_val, lstm_pred_val, 'LSTM'),
    'test': calculate_metrics(y_test, lstm_pred_test, 'LSTM')
}

print(f"  Train R²: {results['LSTM + Attention']['train']['R2']:.4f}")
print(f"  Val R²:   {results['LSTM + Attention']['val']['R2']:.4f}")
print(f"  Test R²:  {results['LSTM + Attention']['test']['R2']:.4f}")

# ============================================================
# 5. ENSEMBLE MODEL
# ============================================================
print("\n" + "="*50)
print("5. ENSEMBLE MODEL")
print("="*50)

# Ağırlıkları validation performansına göre belirle
val_r2_scores = {
    'LR': results['Linear Regression']['val']['R2'],
    'RF': results['Random Forest']['val']['R2'],
    'SVR': results['SVR']['val']['R2'],
    'LSTM': results['LSTM + Attention']['val']['R2']
}

# Negatif R² değerlerini 0 yap
val_r2_scores = {k: max(0, v) for k, v in val_r2_scores.items()}

total_r2 = sum(val_r2_scores.values())
weights = {k: v/total_r2 for k, v in val_r2_scores.items()}

print(f"  Ensemble ağırlıkları:")
print(f"    Linear Regression: {weights['LR']:.4f}")
print(f"    Random Forest:     {weights['RF']:.4f}")
print(f"    SVR:               {weights['SVR']:.4f}")
print(f"    LSTM + Attention:  {weights['LSTM']:.4f}")

# Ensemble tahminleri
ensemble_pred_train = (weights['LR'] * lr_pred_train + 
                       weights['RF'] * rf_pred_train + 
                       weights['SVR'] * svr_pred_train + 
                       weights['LSTM'] * lstm_pred_train)

ensemble_pred_val = (weights['LR'] * lr_pred_val + 
                     weights['RF'] * rf_pred_val + 
                     weights['SVR'] * svr_pred_val + 
                     weights['LSTM'] * lstm_pred_val)

ensemble_pred_test = (weights['LR'] * lr_pred_test + 
                      weights['RF'] * rf_pred_test + 
                      weights['SVR'] * svr_pred_test + 
                      weights['LSTM'] * lstm_pred_test)

results['Ensemble'] = {
    'train': calculate_metrics(y_train, ensemble_pred_train, 'Ensemble'),
    'val': calculate_metrics(y_val, ensemble_pred_val, 'Ensemble'),
    'test': calculate_metrics(y_test, ensemble_pred_test, 'Ensemble')
}

print(f"\n  Train R²: {results['Ensemble']['train']['R2']:.4f}")
print(f"  Val R²:   {results['Ensemble']['val']['R2']:.4f}")
print(f"  Test R²:  {results['Ensemble']['test']['R2']:.4f}")

# ============================================================
# SONUÇ TABLOSU
# ============================================================
print("\n" + "="*70)
print("ABLATION ANALİZİ SONUÇLARI (Fiyat_Kalite_Orani OLMADAN)")
print("="*70)

print("\n" + "-"*70)
print("TEST SETİ PERFORMANSI")
print("-"*70)
print(f"{'Model':<20} {'R²':>10} {'MAE (TL)':>12} {'RMSE (TL)':>12} {'MAPE (%)':>12}")
print("-"*70)

for model_name in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']:
    metrics = results[model_name]['test']
    print(f"{model_name:<20} {metrics['R2']:>10.4f} {metrics['MAE']:>12.4f} {metrics['RMSE']:>12.4f} {metrics['MAPE']:>12.2f}")

print("-"*70)

# Orijinal sonuçlarla karşılaştırma
print("\n" + "="*70)
print("KARŞILAŞTIRMA: Orijinal vs Ablation (Fiyat_Kalite_Orani Olmadan)")
print("="*70)

original_results = {
    'Linear Regression': {'R2': 1.0000, 'MAE': 0.0000, 'RMSE': 0.0000},
    'Random Forest': {'R2': 0.9995, 'MAE': 0.0103, 'RMSE': 0.0571},
    'SVR': {'R2': 0.9297, 'MAE': 0.5844, 'RMSE': 0.7024},
    'LSTM + Attention': {'R2': 0.9912, 'MAE': 0.1782, 'RMSE': 0.2479},
    'Ensemble': {'R2': 0.9942, 'MAE': 0.1646, 'RMSE': 0.2016}
}

print(f"\n{'Model':<20} {'Orijinal R²':>12} {'Ablation R²':>12} {'Fark':>10}")
print("-"*60)

for model_name in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']:
    orig_r2 = original_results[model_name]['R2']
    abl_r2 = results[model_name]['test']['R2']
    diff = abl_r2 - orig_r2
    print(f"{model_name:<20} {orig_r2:>12.4f} {abl_r2:>12.4f} {diff:>10.4f}")

print("-"*60)

# Sonuçları CSV'ye kaydet
results_df = pd.DataFrame({
    'Model': ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble'],
    'Original_R2': [1.0000, 0.9995, 0.9297, 0.9912, 0.9942],
    'Ablation_R2': [results[m]['test']['R2'] for m in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']],
    'Ablation_MAE': [results[m]['test']['MAE'] for m in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']],
    'Ablation_RMSE': [results[m]['test']['RMSE'] for m in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']],
    'Ablation_MAPE': [results[m]['test']['MAPE'] for m in ['Linear Regression', 'Random Forest', 'SVR', 'LSTM + Attention', 'Ensemble']]
})

results_df.to_csv('/home/ubuntu/ablation_analysis/ablation_results.csv', index=False)
print(f"\nSonuçlar kaydedildi: /home/ubuntu/ablation_analysis/ablation_results.csv")

print("\n" + "="*70)
print("ANALİZ TAMAMLANDI")
print("="*70)
