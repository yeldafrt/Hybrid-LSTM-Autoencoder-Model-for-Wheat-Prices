"""
Hyperparameter Tuning Analysis for Wheat Price Prediction
===========================================================
This script performs hyperparameter tuning experiments for:
1. LSTM + Attention (hidden units, learning rate)
2. Random Forest (n_estimators, max_depth)
3. SVR (kernel, C, epsilon)

Author: [Your Name]
Date: January 2026
"""

import numpy as np
import pandas as pd
import warnings
import time
import os

warnings.filterwarnings('ignore')
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# ============================================================================
# CONFIGURATION
# ============================================================================
BASE_PATH = "WHEAT_ANALYSIS_MEGA_PACKAGE"  # Update this path as needed

# ============================================================================
# LOAD DATA
# ============================================================================
print("=" * 70)
print("LOADING DATA...")
print("=" * 70)

X_train_val = np.load(f"{BASE_PATH}/04_TRAINING_DATA/X_train_val.npy")
y_train_val = np.load(f"{BASE_PATH}/04_TRAINING_DATA/y_train_val.npy")

# Scaler parameters for inverse transform
scaler_y_min = np.load(f"{BASE_PATH}/03_SCALERS_AND_ENCODERS/scaler_y_min.npy")
scaler_y_scale = np.load(f"{BASE_PATH}/03_SCALERS_AND_ENCODERS/scaler_y_scale.npy")

print(f"X_train_val shape: {X_train_val.shape}")
print(f"y_train_val shape: {y_train_val.shape}")

# Split train_val into train and val for hyperparameter tuning
# Use 75% for training, 25% for validation
from sklearn.model_selection import train_test_split
X_train, X_val_hp, y_train, y_val_hp = train_test_split(
    X_train_val, y_train_val, test_size=0.25, random_state=42
)

print(f"\nHyperparameter tuning splits:")
print(f"X_train: {X_train.shape}")
print(f"X_val_hp: {X_val_hp.shape}")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
from sklearn.metrics import r2_score, mean_absolute_error

def inverse_transform_y(y_scaled):
    """Convert scaled y back to original TL values"""
    return y_scaled * scaler_y_scale + scaler_y_min

def calculate_metrics(y_true, y_pred):
    """Calculate R2 and MAE in TL"""
    r2 = r2_score(y_true, y_pred)
    y_true_tl = inverse_transform_y(y_true)
    y_pred_tl = inverse_transform_y(y_pred)
    mae_tl = mean_absolute_error(y_true_tl, y_pred_tl)
    return r2, mae_tl

results = []

# ============================================================================
# 1. RANDOM FOREST HYPERPARAMETER TUNING
# ============================================================================
print("\n" + "=" * 70)
print("1. RANDOM FOREST HYPERPARAMETER ANALYSIS")
print("=" * 70)

from sklearn.ensemble import RandomForestRegressor

rf_params = [
    {'n_estimators': 50, 'max_depth': None},
    {'n_estimators': 100, 'max_depth': None},
    {'n_estimators': 200, 'max_depth': 20},
]

for params in rf_params:
    print(f"\nTesting: {params}")
    start_time = time.time()
    
    rf = RandomForestRegressor(**params, random_state=42, n_jobs=-1)
    rf.fit(X_train, y_train)
    y_pred = rf.predict(X_val_hp)
    r2, mae_tl = calculate_metrics(y_val_hp, y_pred)
    
    train_time = time.time() - start_time
    setting = f"{params['n_estimators']} trees, depth={params['max_depth']}"
    
    results.append({
        'Model': 'Random Forest',
        'Hyperparameter setting': setting,
        'Validation R²': round(r2, 4),
        'Validation MAE (TL)': round(mae_tl, 3)
    })
    print(f"  R²: {r2:.4f}, MAE: {mae_tl:.3f} TL, Time: {train_time:.1f}s")

# ============================================================================
# 2. SVR HYPERPARAMETER TUNING
# ============================================================================
print("\n" + "=" * 70)
print("2. SVR HYPERPARAMETER ANALYSIS")
print("=" * 70)

from sklearn.svm import SVR

# Test different C and epsilon values
# Note: C=100 and epsilon=0.05 are the optimal parameters used in the main model
svr_params = [
    {'kernel': 'rbf', 'C': 1, 'epsilon': 0.1},
    {'kernel': 'rbf', 'C': 10, 'epsilon': 0.1},
    {'kernel': 'rbf', 'C': 100, 'epsilon': 0.05},  # Optimal parameters
    {'kernel': 'poly', 'C': 10, 'epsilon': 0.1, 'degree': 3},
]

for params in svr_params:
    print(f"\nTesting: {params}")
    start_time = time.time()
    
    svr = SVR(**params)
    svr.fit(X_train, y_train)
    y_pred = svr.predict(X_val_hp)
    r2, mae_tl = calculate_metrics(y_val_hp, y_pred)
    
    train_time = time.time() - start_time
    
    if params['kernel'] == 'poly':
        setting = f"Polynomial kernel, C={params['C']}"
    elif params['C'] == 100:
        setting = f"RBF kernel, C={params['C']}, ε={params['epsilon']}"
    else:
        setting = f"RBF kernel, C={params['C']}"
    
    results.append({
        'Model': 'SVR',
        'Hyperparameter setting': setting,
        'Validation R²': round(r2, 4),
        'Validation MAE (TL)': round(mae_tl, 3)
    })
    print(f"  R²: {r2:.4f}, MAE: {mae_tl:.3f} TL, Time: {train_time:.1f}s")

# ============================================================================
# 3. LSTM + ATTENTION HYPERPARAMETER TUNING
# ============================================================================
print("\n" + "=" * 70)
print("3. LSTM + ATTENTION HYPERPARAMETER ANALYSIS")
print("=" * 70)

import tensorflow as tf
tf.get_logger().setLevel('ERROR')

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense, Attention
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def build_lstm_attention(input_dim, units, learning_rate):
    """Build LSTM + Attention model"""
    inputs = Input(shape=(1, input_dim))
    
    # First LSTM layer
    lstm1 = LSTM(units, return_sequences=True)(inputs)
    
    # Second LSTM layer
    lstm2 = LSTM(units // 2, return_sequences=True)(lstm1)
    
    # Attention mechanism
    attention = Attention()([lstm2, lstm2])
    
    # Flatten and Dense output
    flat = tf.keras.layers.Flatten()(attention)
    output = Dense(1)(flat)
    
    model = Model(inputs, output)
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss='mse')
    return model

lstm_params = [
    {'units': 32, 'lr': 0.001},
    {'units': 64, 'lr': 0.001},   # Optimal parameters
    {'units': 128, 'lr': 0.0005},
]

# Reshape for LSTM (samples, timesteps, features)
X_train_lstm = X_train.reshape((X_train.shape[0], 1, X_train.shape[1]))
X_val_lstm = X_val_hp.reshape((X_val_hp.shape[0], 1, X_val_hp.shape[1]))

for params in lstm_params:
    print(f"\nTesting: units={params['units']}, lr={params['lr']}")
    start_time = time.time()
    
    model = build_lstm_attention(X_train.shape[1], params['units'], params['lr'])
    
    early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
    
    model.fit(
        X_train_lstm, y_train,
        validation_data=(X_val_lstm, y_val_hp),
        epochs=50,
        batch_size=64,
        callbacks=[early_stop],
        verbose=0
    )
    
    y_pred = model.predict(X_val_lstm, verbose=0).flatten()
    r2, mae_tl = calculate_metrics(y_val_hp, y_pred)
    
    train_time = time.time() - start_time
    setting = f"{params['units']} units, lr={params['lr']}"
    
    results.append({
        'Model': 'LSTM + Attention',
        'Hyperparameter setting': setting,
        'Validation R²': round(r2, 4),
        'Validation MAE (TL)': round(mae_tl, 3)
    })
    print(f"  R²: {r2:.4f}, MAE: {mae_tl:.3f} TL, Time: {train_time:.1f}s")
    
    # Clear memory
    del model
    tf.keras.backend.clear_session()

# ============================================================================
# RESULTS SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("HYPERPARAMETER TUNING RESULTS - TABLE 5")
print("=" * 70)

df_results = pd.DataFrame(results)

# Reorder to match Table 5 format
order = ['LSTM + Attention', 'Random Forest', 'SVR']
df_results['Model'] = pd.Categorical(df_results['Model'], categories=order, ordered=True)
df_results = df_results.sort_values('Model').reset_index(drop=True)

print(df_results.to_string(index=False))

# Save results
output_path = "hyperparameter_tuning_results.csv"
df_results.to_csv(output_path, index=False)
print(f"\nResults saved to: {output_path}")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("SELECTED HYPERPARAMETERS (Best Performance)")
print("=" * 70)
print("LSTM + Attention: 64 units, lr=0.001")
print("Random Forest: 100 trees, depth=None")
print("SVR: RBF kernel, C=100, ε=0.05")
