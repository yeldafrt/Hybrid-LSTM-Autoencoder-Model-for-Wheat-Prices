# Buğday Fiyat Tahminlemesi ve Anomali Tespiti - Production Package

## Dosya Yapısı

```
production_models/
├── linear_regression.pkl          # Linear Regression modeli
├── random_forest.pkl              # Random Forest modeli
├── svr.pkl                        # Support Vector Regression modeli
├── lstm_attention.h5              # LSTM + Attention modeli
├── autoencoder.h5                 # Autoencoder (anomali tespiti)
├── encoder.h5                     # Encoder
├── scaler_X_min.npy               # X normalizasyon min değeri
├── scaler_X_scale.npy             # X normalizasyon scale değeri
├── scaler_y_min.npy               # Y normalizasyon min değeri
├── scaler_y_scale.npy             # Y normalizasyon scale değeri
├── anomaly_threshold.npy          # Anomali threshold değeri
├── sinif_encoder.npy              # Sınıf encoder
├── urun_encoder.npy               # Ürün encoder
└── predict.py                     # Production prediction script
```

## Kullanım

### 1. Basit Tahmin

```python
from predict import WheatPricePredictor
import numpy as np

# Modeli yükle
predictor = WheatPricePredictor()

# Veri yükle (31 özellik)
X = np.load('your_data.npy')  # Shape: (n_samples, 31)

# Tahmin yap
results = predictor.predict_with_anomaly_detection(X)

# Sonuçları göster
print(results.head())
```

### 2. Sadece Fiyat Tahmini

```python
prices = predictor.predict_price(X)
print(prices)
```

### 3. Sadece Anomali Tespiti

```python
anomalies, mse = predictor.detect_anomalies(X)
print(f"Anomaliler: {anomalies}")
print(f"MSE: {mse}")
```

## Model Performansı (External Test Seti)

| Model | R² Score | MAE (TL) | RMSE (TL) | MAPE (%) |
|-------|----------|----------|-----------|----------|
| Linear Regression | 1.0000 | 0.0000 | 0.0000 | 0.00% |
| Random Forest | 0.9995 | 0.0103 | 0.0571 | 0.44% |
| **Ensemble** | **0.9942** | **0.1646** | **0.2016** | **5.16%** |
| LSTM | 0.9912 | 0.1782 | 0.2479 | 5.89% |
| SVR | 0.9297 | 0.5844 | 0.7024 | 16.42% |

## Anomali Tespiti Performansı

- **Test Seti Boyutu:** 7.604 kayıt
- **Tespit Edilen Anomaliler:** 390 (5.13%)
- **Normal Kayıtlar:** 7.214 (94.87%)
- **Threshold:** 0.001378

## Özellikler (31 adet)

1. Rutubet
2. Hektolitre
3. Protein
4. Kusurlu Taneler
5. Kırık Tane
6. Çiliz Burışuk
7. Yabancı Madde
8. Kavuz
9. ... (ve 23 daha)

## Gerekli Kütüphaneler

```bash
pip install numpy pandas scikit-learn tensorflow
```

## Notlar

- Tüm giriş verileri 31 özellik içermelidir
- Veriler otomatik olarak normalize edilir
- Çıktı TL cinsinden fiyat ve anomali bilgisidir
- Modeller 60% train, 20% validation, 20% test setinde eğitilmiştir
- 5-Fold Cross-Validation ile doğrulanmıştır

## İletişim

Q1 Dergi Yayını için: Buğday Fiyat Tahminlemesi ve Anomali Tespiti Çalışması
