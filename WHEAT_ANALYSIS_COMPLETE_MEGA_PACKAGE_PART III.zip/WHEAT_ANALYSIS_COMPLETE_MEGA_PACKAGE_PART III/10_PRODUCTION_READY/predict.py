#!/usr/bin/env python3
"""
Buğday Fiyat Tahminlemesi ve Anomali Tespiti - Production Script
Gerçek dünya verilerine ait tahminler yapmak için kullanılır.
"""

import numpy as np
import pandas as pd
import joblib
import tensorflow as tf
from tensorflow import keras
import warnings
warnings.filterwarnings('ignore')

class WheatPricePredictor:
    """Buğday fiyat tahminlemesi ve anomali tespiti için production modeli"""
    
    def __init__(self, model_dir='production_models'):
        """Modelleri ve scalers'ı yükle"""
        print("Modeller yükleniyor...")
        
        # Modelleri yükle
        self.lr_model = joblib.load(f'{model_dir}/linear_regression.pkl')
        self.rf_model = joblib.load(f'{model_dir}/random_forest.pkl')
        self.svr_model = joblib.load(f'{model_dir}/svr.pkl')
        self.lstm_model = keras.models.load_model(f'{model_dir}/lstm_attention.h5', compile=False)
        self.autoencoder = keras.models.load_model(f'{model_dir}/autoencoder.h5', compile=False)
        
        # Scalers yükle
        self.scaler_X_min = float(np.load(f'{model_dir}/scaler_X_min.npy'))
        self.scaler_X_scale = float(np.load(f'{model_dir}/scaler_X_scale.npy'))
        self.scaler_y_min = float(np.load(f'{model_dir}/scaler_y_min.npy'))
        self.scaler_y_scale = float(np.load(f'{model_dir}/scaler_y_scale.npy'))
        
        # Anomali threshold
        self.anomaly_threshold = float(np.load(f'{model_dir}/anomaly_threshold.npy')[0])
        
        print("✓ Modeller başarıyla yüklendi")
    
    def normalize_features(self, X):
        """Özellikleri normalize et"""
        return (X - self.scaler_X_min) / (self.scaler_X_scale + 1e-8)
    
    def denormalize_price(self, y_norm):
        """Fiyatı denormalize et"""
        return y_norm * self.scaler_y_scale + self.scaler_y_min
    
    def predict_price(self, X):
        """Fiyat tahmini yap (Ensemble)"""
        # Normalizasyon
        X_norm = self.normalize_features(X)
        
        # Tahminler
        y_lr = self.lr_model.predict(X_norm, verbose=0)
        y_rf = self.rf_model.predict(X_norm, verbose=0)
        y_svr = self.svr_model.predict(X_norm, verbose=0)
        y_lstm = self.lstm_model.predict(X_norm, verbose=0).flatten()
        
        # Ensemble (ağırlıklı ortalama)
        y_ensemble = (y_lr * 0.2551 + y_rf * 0.2549 + y_svr * 0.2371 + y_lstm * 0.2528)
        
        # Denormalizasyon
        return self.denormalize_price(y_ensemble)
    
    def detect_anomalies(self, X):
        """Anomali tespiti yap"""
        # Normalizasyon
        X_norm = self.normalize_features(X)
        
        # Reconstruction error hesapla
        X_pred = self.autoencoder.predict(X_norm, verbose=0)
        mse = np.mean(np.square(X_norm - X_pred), axis=1)
        
        # Anomali labels
        is_anomaly = (mse > self.anomaly_threshold).astype(int)
        
        return is_anomaly, mse
    
    def predict_with_anomaly_detection(self, X):
        """Fiyat tahmini + Anomali tespiti"""
        prices = self.predict_price(X)
        anomalies, mse = self.detect_anomalies(X)
        
        results = pd.DataFrame({
            'Predicted_Price_TL': prices,
            'Is_Anomaly': anomalies,
            'Reconstruction_Error': mse,
            'Anomaly_Risk': ['HIGH' if a == 1 else 'LOW' for a in anomalies]
        })
        
        return results


# Örnek kullanım
if __name__ == "__main__":
    print("=" * 80)
    print("BUĞDAY FİYAT TAHMİNLEMESİ VE ANOMALI TESPİTİ - PRODUCTION")
    print("=" * 80)
    
    # Modeli yükle
    predictor = WheatPricePredictor()
    
    # Örnek veri yükle (test seti)
    X_test = np.load('npy_files/X_test_holdout.npy')
    y_test = np.load('npy_files/y_test_holdout.npy')
    
    # Denormalize test labels
    y_test_denorm = predictor.denormalize_price(y_test)
    
    print(f"\nTest Seti Boyutu: {X_test.shape[0]} kayıt")
    print(f"Özellik Sayısı: {X_test.shape[1]}")
    
    # Tahminler yap
    print("\nTahminler yapılıyor...")
    results = predictor.predict_with_anomaly_detection(X_test)
    
    # Sonuçları göster
    print("\n" + "=" * 80)
    print("İLK 10 TAHMIN SONUCU")
    print("=" * 80)
    
    results_with_actual = results.copy()
    results_with_actual['Actual_Price_TL'] = y_test_denorm
    results_with_actual['Error_TL'] = abs(results_with_actual['Predicted_Price_TL'] - results_with_actual['Actual_Price_TL'])
    
    print(results_with_actual.head(10).to_string())
    
    # İstatistikler
    print("\n" + "=" * 80)
    print("TAHMIN PERFORMANSI")
    print("=" * 80)
    
    mae = np.mean(results_with_actual['Error_TL'])
    rmse = np.sqrt(np.mean(results_with_actual['Error_TL'] ** 2))
    anomaly_count = (results['Is_Anomaly'] == 1).sum()
    
    print(f"\nOrtalama Mutlak Hata (MAE): {mae:.4f} TL")
    print(f"Kök Ortalama Kare Hatası (RMSE): {rmse:.4f} TL")
    print(f"Tespit Edilen Anomaliler: {anomaly_count} ({anomaly_count/len(results)*100:.2f}%)")
    
    # Sonuçları kaydet
    results_with_actual.to_csv('predictions_output.csv', index=False)
    print(f"\n✓ Sonuçlar 'predictions_output.csv' dosyasına kaydedildi")
