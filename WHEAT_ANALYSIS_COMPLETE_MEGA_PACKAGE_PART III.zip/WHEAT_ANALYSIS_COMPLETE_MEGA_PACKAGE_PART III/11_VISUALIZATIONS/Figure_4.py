"""
Figure 4: Model Robustness and Anomaly Detection
600 DPI, TIFF Format, English Labels, High Quality
REAL DATA - NO SIMULATION

Panels:
(a) Cross-Validation Stability (All Models: Linear Regression, Random Forest, SVR)
(b) Anomaly Detection Results (Test Set)
(c) Price Trend Over Time (Real Daily Prices)
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# REAL DATA LOADING
# ============================================================================

# Panel (a): Cross-Validation Stability - ALL MODELS
# Source: /home/ubuntu/upload/WHEAT_ANALYSIS_MEGA_PACKAGE/08_ANALYSIS_RESULTS/cv_*.csv
cv_lr = pd.read_csv('/home/ubuntu/upload/WHEAT_ANALYSIS_MEGA_PACKAGE/08_ANALYSIS_RESULTS/cv_linear_regression.csv')
cv_rf = pd.read_csv('/home/ubuntu/upload/WHEAT_ANALYSIS_MEGA_PACKAGE/08_ANALYSIS_RESULTS/cv_random_forest.csv')
cv_svr = pd.read_csv('/home/ubuntu/upload/WHEAT_ANALYSIS_MEGA_PACKAGE/08_ANALYSIS_RESULTS/cv_svr.csv')

# Extract mean Test R² for each model
models = ['Linear\nRegression', 'Random\nForest', 'SVR']
test_r2_means = [
    cv_lr[cv_lr['Fold'] == 'Mean']['Test R²'].values[0],
    cv_rf[cv_rf['Fold'] == 'Mean']['Test R²'].values[0],
    cv_svr[cv_svr['Fold'] == 'Mean']['Test R²'].values[0]
]
test_r2_stds = [
    cv_lr[cv_lr['Fold'] == 'Std']['Test R²'].values[0],
    cv_rf[cv_rf['Fold'] == 'Std']['Test R²'].values[0],
    cv_svr[cv_svr['Fold'] == 'Std']['Test R²'].values[0]
]

# Panel (b): Anomaly Detection Results
# Source: /home/ubuntu/upload/WHEAT_ANALYSIS_MEGA_PACKAGE/08_ANALYSIS_RESULTS/anomaly_detailed_analysis.csv
total_records = 7604  # Test set size
anomalies = 390       # Detected anomalies
normal = total_records - anomalies
anomaly_percentage = (anomalies / total_records) * 100

# Panel (c): Price Trend Over Time - REAL DATA
# Source: /home/ubuntu/upload/buğday_veri.xlsx
df = pd.read_excel('/home/ubuntu/upload/buğday_veri.xlsx')
df_sorted = df.sort_values('FisTarih')
daily_prices = df_sorted.groupby('FisTarih')['BirimFiyati'].mean()

dates = daily_prices.index
prices = daily_prices.values

print(f"Real data loaded:")
print(f"Models: {models}")
print(f"Test R² Means: {test_r2_means}")
print(f"Test R² Stds: {test_r2_stds}")
print(f"Total days: {len(daily_prices)}")
print(f"Date range: {dates[0].date()} to {dates[-1].date()}")
print(f"Mean price: {prices.mean():.2f} TL")

# ============================================================================
# FIGURE CREATION
# ============================================================================

fig = plt.figure(figsize=(20, 12), dpi=600)
gs = fig.add_gridspec(1, 3, hspace=0.3, wspace=0.35)

# ============================================================================
# PANEL (a): Cross-Validation Stability - ALL MODELS (Bar Chart with Error Bars)
# ============================================================================
ax1 = fig.add_subplot(gs[0, 0])

x_pos = np.arange(len(models))
width = 0.5

# Convert negative std to positive for visualization
test_r2_stds_abs = [abs(std) for std in test_r2_stds]

bars = ax1.bar(x_pos, test_r2_means, width, 
               yerr=test_r2_stds_abs, capsize=10,
               color=['#2E86AB', '#F18F01', '#A23B72'],
               edgecolor='black', linewidth=2,
               error_kw=dict(elinewidth=2, capthick=2, ecolor='black'))

# Add value labels on bars
for i, (mean, std) in enumerate(zip(test_r2_means, test_r2_stds_abs)):
    ax1.text(i, mean + std + 0.002, f'{mean:.4f}', 
            ha='center', va='bottom', fontsize=14, fontweight='bold')

ax1.set_ylabel('Mean Test R² Score', fontsize=18, fontweight='bold')
ax1.set_title('(a)', fontsize=20, fontweight='bold', loc='left', pad=15)
ax1.set_xticks(x_pos)
ax1.set_xticklabels(models, fontsize=16, fontweight='bold')
ax1.set_ylim(0.9, 1.01)
ax1.tick_params(axis='y', labelsize=14)
ax1.grid(axis='y', alpha=0.3, linestyle='--')

# Add legend
ax1.text(0.5, 0.05, f'5-Fold Cross-Validation Results', 
        transform=ax1.transAxes, fontsize=13, fontweight='bold',
        ha='center', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8, edgecolor='black', linewidth=1.5))

# ============================================================================
# PANEL (b): Anomaly Detection Results (Pie Chart)
# ============================================================================
ax2 = fig.add_subplot(gs[0, 1])

sizes = [normal, anomalies]
labels = [f'Normal Records\n(n={normal:,})\n{100-anomaly_percentage:.2f}%', 
          f'Anomalies\n(n={anomalies})\n{anomaly_percentage:.2f}%']
colors = ['#2E86AB', '#C73E1D']
explode = (0, 0.15)

wedges, texts, autotexts = ax2.pie(sizes, labels=labels, colors=colors, autopct='',
                                     explode=explode, startangle=90,
                                     wedgeprops=dict(edgecolor='black', linewidth=2),
                                     textprops=dict(fontsize=14, fontweight='bold'))

ax2.set_title('(b)', fontsize=20, fontweight='bold', loc='left', pad=15)

# ============================================================================
# PANEL (c): Price Trend Over Time (Line Plot) - REAL DATA
# ============================================================================
ax3 = fig.add_subplot(gs[0, 2])

ax3.plot(dates, prices, linewidth=3, color='#2E86AB', label='Wheat Price', marker='o', markersize=3)
ax3.fill_between(dates, prices, alpha=0.3, color='#2E86AB')

# Add mean line
mean_price = np.mean(prices)
ax3.axhline(mean_price, color='red', linestyle='--', linewidth=2.5, 
           label=f'Mean Price: {mean_price:.2f} TL')

ax3.set_xlabel('Date', fontsize=18, fontweight='bold')
ax3.set_ylabel('Price (TL)', fontsize=18, fontweight='bold')
ax3.set_title('(c)', fontsize=20, fontweight='bold', loc='left', pad=15)
ax3.legend(fontsize=14, loc='best', framealpha=0.95, edgecolor='black', fancybox=True)
ax3.grid(True, alpha=0.3, linestyle='--')
ax3.tick_params(axis='both', labelsize=14)

# Rotate x-axis labels for better readability
ax3.tick_params(axis='x', rotation=45)
plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha='right')

# ============================================================================
# SAVE FIGURE
# ============================================================================
plt.savefig('/home/ubuntu/Figure_4_Robustness_Anomaly_Detection.tiff', 
            dpi=600, bbox_inches='tight', facecolor='white', edgecolor='none', format='tiff')

print("\n✓ Figure 4 created successfully with ALL MODELS in Panel (a)!")
print("✓ File: /home/ubuntu/Figure_4_Robustness_Anomaly_Detection.tiff")
print("✓ Format: TIFF (600 DPI)")
print("✓ Size: 20×12 inches")
print("✓ Resolution: 12000×7200 pixels")

import os
size = os.path.getsize('/home/ubuntu/Figure_4_Robustness_Anomaly_Detection.tiff') / (1024*1024)
print(f"✓ File size: {size:.1f} MB")

plt.close()
