"""
Figure 2: Model Architecture - UPDATED
Q1 Journal Format - 600 DPI - PNG Format - English Only

UPDATES based on reviewer feedback:
- Increased font sizes for better readability
- Larger text annotations
- Optimized for MDPI requirements (min 600 DPI)
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# Create figure - larger size for better readability
fig, ax = plt.subplots(figsize=(20, 16), dpi=600)
ax.set_xlim(0, 10)
ax.set_ylim(0, 14)
ax.axis('off')

# Color scheme
color_input = '#E8F4F8'
color_lstm = '#B3E5FC'
color_ae = '#FFE0B2'
color_ensemble = '#C8E6C9'
color_output = '#F8BBD0'

# ============ INPUT LAYER ============
input_box = FancyBboxPatch((0.5, 11.5), 2, 1.2, boxstyle="round,pad=0.1", 
                           edgecolor='black', facecolor=color_input, linewidth=3.5)
ax.add_patch(input_box)
ax.text(1.5, 12.1, 'Input\n31 Features', fontsize=20, fontweight='bold', ha='center', va='center')

# ============ LSTM + ATTENTION ============
lstm_input_box = FancyBboxPatch((0.2, 9.5), 2.5, 1, boxstyle="round,pad=0.1",
                                edgecolor='black', facecolor=color_lstm, linewidth=3)
ax.add_patch(lstm_input_box)
ax.text(1.45, 10, 'LSTM Layer\n64 Units', fontsize=18, fontweight='bold', ha='center', va='center')

lstm_hidden_box = FancyBboxPatch((0.2, 7.8), 2.5, 1, boxstyle="round,pad=0.1",
                                 edgecolor='black', facecolor=color_lstm, linewidth=3)
ax.add_patch(lstm_hidden_box)
ax.text(1.45, 8.3, 'LSTM Layer\n32 Units', fontsize=18, fontweight='bold', ha='center', va='center')

attention_box = FancyBboxPatch((0.2, 6.1), 2.5, 1, boxstyle="round,pad=0.1",
                               edgecolor='black', facecolor='#FFCCBC', linewidth=3)
ax.add_patch(attention_box)
ax.text(1.45, 6.6, 'Attention\nMechanism', fontsize=18, fontweight='bold', ha='center', va='center')

lstm_output_box = FancyBboxPatch((0.2, 4.4), 2.5, 1, boxstyle="round,pad=0.1",
                                 edgecolor='black', facecolor=color_lstm, linewidth=3)
ax.add_patch(lstm_output_box)
ax.text(1.45, 4.9, 'Dense Output\n1 Unit', fontsize=18, fontweight='bold', ha='center', va='center')

# ============ AUTOENCODER ============
encoder_box = FancyBboxPatch((3.5, 9.5), 2.5, 1, boxstyle="round,pad=0.1",
                             edgecolor='black', facecolor=color_ae, linewidth=3)
ax.add_patch(encoder_box)
ax.text(4.75, 10, 'Encoder\n31→16→8→4', fontsize=18, fontweight='bold', ha='center', va='center')

bottleneck_box = FancyBboxPatch((3.5, 7.8), 2.5, 1, boxstyle="round,pad=0.1",
                                edgecolor='black', facecolor='#FFD54F', linewidth=3)
ax.add_patch(bottleneck_box)
ax.text(4.75, 8.3, 'Bottleneck\n4 Units', fontsize=18, fontweight='bold', ha='center', va='center')

decoder_box = FancyBboxPatch((3.5, 6.1), 2.5, 1, boxstyle="round,pad=0.1",
                             edgecolor='black', facecolor=color_ae, linewidth=3)
ax.add_patch(decoder_box)
ax.text(4.75, 6.6, 'Decoder\n4→8→16→31', fontsize=18, fontweight='bold', ha='center', va='center')

anomaly_box = FancyBboxPatch((3.5, 4.4), 2.5, 1, boxstyle="round,pad=0.1",
                             edgecolor='black', facecolor='#F48FB1', linewidth=3)
ax.add_patch(anomaly_box)
ax.text(4.75, 4.9, 'Anomaly Score\n(MSE)', fontsize=18, fontweight='bold', ha='center', va='center')

# ============ OTHER MODELS ============
lr_box = FancyBboxPatch((6.8, 9.5), 2.5, 1, boxstyle="round,pad=0.1",
                        edgecolor='black', facecolor='#C5E1A5', linewidth=3)
ax.add_patch(lr_box)
ax.text(8.05, 10, 'Linear\nRegression', fontsize=18, fontweight='bold', ha='center', va='center')

rf_box = FancyBboxPatch((6.8, 8.1), 2.5, 1, boxstyle="round,pad=0.1",
                        edgecolor='black', facecolor='#A1887F', linewidth=3)
ax.add_patch(rf_box)
ax.text(8.05, 8.6, 'Random Forest\n100 Trees', fontsize=18, fontweight='bold', ha='center', va='center')

svr_box = FancyBboxPatch((6.8, 6.7), 2.5, 1, boxstyle="round,pad=0.1",
                         edgecolor='black', facecolor='#B0BEC5', linewidth=3)
ax.add_patch(svr_box)
ax.text(8.05, 7.2, 'SVR\n(RBF Kernel)', fontsize=18, fontweight='bold', ha='center', va='center')

# ============ ENSEMBLE ============
ensemble_box = FancyBboxPatch((3, 2), 4, 1.2, boxstyle="round,pad=0.1",
                              edgecolor='black', facecolor=color_ensemble, linewidth=3.5)
ax.add_patch(ensemble_box)
ax.text(5, 2.8, 'Ensemble Model\n(Weighted Average)', fontsize=20, fontweight='bold', ha='center', va='center')
ax.text(5, 2.25, 'Weights: LR=0.255, RF=0.255, SVR=0.237, LSTM=0.253', fontsize=16, ha='center', va='center')

# ============ OUTPUT ============
output_box = FancyBboxPatch((3.5, 0.2), 3, 1, boxstyle="round,pad=0.1",
                            edgecolor='black', facecolor=color_output, linewidth=3.5)
ax.add_patch(output_box)
ax.text(5, 0.7, 'Price Prediction + Anomaly Detection', fontsize=18, fontweight='bold', ha='center', va='center')

# ============ ARROWS ============
# From input to models
arrow1 = FancyArrowPatch((1.5, 11.5), (1.45, 10.5), arrowstyle='->', mutation_scale=35, linewidth=3, color='black')
ax.add_patch(arrow1)

arrow2 = FancyArrowPatch((1.5, 11.5), (4.75, 10.5), arrowstyle='->', mutation_scale=35, linewidth=3, color='black')
ax.add_patch(arrow2)

arrow3 = FancyArrowPatch((1.5, 11.5), (8.05, 10.5), arrowstyle='->', mutation_scale=35, linewidth=3, color='black')
ax.add_patch(arrow3)

# LSTM chain
arrow4 = FancyArrowPatch((1.45, 9.5), (1.45, 8.8), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow4)

arrow5 = FancyArrowPatch((1.45, 7.8), (1.45, 7.1), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow5)

arrow6 = FancyArrowPatch((1.45, 6.1), (1.45, 5.4), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow6)

# Autoencoder chain
arrow7 = FancyArrowPatch((4.75, 9.5), (4.75, 8.8), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow7)

arrow8 = FancyArrowPatch((4.75, 7.8), (4.75, 7.1), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow8)

arrow9 = FancyArrowPatch((4.75, 6.1), (4.75, 5.4), arrowstyle='->', mutation_scale=30, linewidth=2.5, color='black')
ax.add_patch(arrow9)

# To ensemble
arrow10 = FancyArrowPatch((1.45, 4.4), (4, 3.2), arrowstyle='->', mutation_scale=30, linewidth=3, color='black')
ax.add_patch(arrow10)

arrow11 = FancyArrowPatch((4.75, 4.4), (5, 3.2), arrowstyle='->', mutation_scale=30, linewidth=3, color='black')
ax.add_patch(arrow11)

arrow12 = FancyArrowPatch((8.05, 9.5), (6.5, 3.2), arrowstyle='->', mutation_scale=30, linewidth=3, color='black')
ax.add_patch(arrow12)

arrow13 = FancyArrowPatch((8.05, 8.1), (6.5, 3.2), arrowstyle='->', mutation_scale=30, linewidth=3, color='black')
ax.add_patch(arrow13)

arrow14 = FancyArrowPatch((8.05, 6.7), (6.5, 3.2), arrowstyle='->', mutation_scale=30, linewidth=3, color='black')
ax.add_patch(arrow14)

# To output
arrow15 = FancyArrowPatch((5, 2), (5, 1.2), arrowstyle='->', mutation_scale=35, linewidth=3, color='black')
ax.add_patch(arrow15)

# Save as PNG (600 DPI)
plt.savefig('/home/ubuntu/Figure_2_Model_Architecture_Updated.png', dpi=600, bbox_inches='tight',
            facecolor='white', edgecolor='none', format='png')

print("=" * 60)
print("✓ Figure 2 UPDATED with larger fonts!")
print("=" * 60)
print("FONT SIZE CHANGES:")
print("  - Input/Ensemble/Output boxes: 20pt (was 15-16pt)")
print("  - Model boxes: 18pt (was 14pt)")
print("  - Weights text: 16pt (was 12pt)")
print("  - Line widths: increased by ~20%")
print("  - Arrow sizes: increased")
print("=" * 60)
print("✓ PNG File: /home/ubuntu/Figure_2_Model_Architecture_Updated.png (600 DPI)")
print("=" * 60)

plt.close()
