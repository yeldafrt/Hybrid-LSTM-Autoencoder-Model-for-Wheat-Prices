"""
Figure 1: Dataset Overview and Data Quality Assessment (LARGE FONTS VERSION)
Q1 Journal Format - 600 DPI - PNG Format - English Only

MAJOR FONT SIZE INCREASES:
- All fonts increased by 50-70% for better readability after scaling
- Legend fonts significantly larger
- Axis labels and tick labels much larger
- Optimized for MDPI requirements (min 600 DPI)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# CORRECTED VALUES - Based on data_split_summary.csv
n_total = 38019
n_train = 22811  # 60%
n_val = 7604     # 20%
n_test = 7604    # 20%

n_features = 23  # Original features

# Hardcoded values (since we don't have the data file)
missing_count = 922
missing_pct = 2.43

anomalies = 390
anomalies_pct = 1.03

zero_price = 23
zero_price_pct = 0.1

zero_quantity = 22
zero_quantity_pct = 0.1

valid_data = 36662
valid_pct = 96.4

# Product distribution (hardcoded from original)
product_names = ['Corn (Yellow)', 'Barley (White)', 'Durum Wheat', 'Esperia', 
                 'Mixed Red Wheat', 'Variety-1252', 'Bayraktar', 'Lucilla']
product_values = [18780, 4942, 2575, 2487, 1624, 1180, 884, 777]

# Quality parameters (hardcoded from original)
quality_params = ['Moisture', 'Hectolitre', 'Protein', 'Defective\nGrains', 
                  'Broken\nGrains', 'Immature\nGrains', 'Foreign\nMatter', 'Husk']
min_vals = [0, 0, 0, 0, 0, 0, 0, 0]
mean_vals = [12.5, 75, 11, 2, 3, 2, 1, 2]
max_vals = [100, 100, 100, 200, 100, 100, 140, 100]

# Set style with MUCH LARGER fonts - 50-70% increase
sns.set_style("whitegrid")
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 22  # Base font size - was 14
plt.rcParams['axes.labelsize'] = 26  # was 16
plt.rcParams['axes.titlesize'] = 28  # was 18
plt.rcParams['xtick.labelsize'] = 22  # was 14
plt.rcParams['ytick.labelsize'] = 22  # was 14
plt.rcParams['legend.fontsize'] = 22  # was 14

# Create figure - larger for better readability
fig = plt.figure(figsize=(22, 18), dpi=600)
gs = GridSpec(2, 2, figure=fig, hspace=0.45, wspace=0.40)

# ============ PANEL A: Dataset Statistics ============
ax_a = fig.add_subplot(gs[0, 0])

stats_data = {
    'Total Records': n_total,
    'Features': n_features,
    'Training Set': n_train,
    'Validation Set': n_val,
    'Test Set': n_test,
    'Missing Data (%)': missing_pct,
    'Anomalies (%)': anomalies_pct
}

categories = list(stats_data.keys())
values = list(stats_data.values())
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']

bars = ax_a.barh(categories, values, color=colors, edgecolor='black', linewidth=3)

for i, (bar, val) in enumerate(zip(bars, values)):
    if i < 5:
        ax_a.text(val + 800, i, f'{int(val):,}', va='center', fontsize=22, fontweight='bold')
    else:
        ax_a.text(val + 0.25, i, f'{val:.2f}%', va='center', fontsize=22, fontweight='bold')

ax_a.set_xlabel('Value', fontsize=26, fontweight='bold')
ax_a.set_yticklabels(categories, fontsize=22, fontweight='bold')
ax_a.text(-0.15, 1.05, '(a)', transform=ax_a.transAxes, fontsize=32, fontweight='bold')
ax_a.grid(axis='x', alpha=0.4, linestyle='--', linewidth=1.5)
ax_a.set_xlim(0, max(values) * 1.25)

# ============ PANEL B: Quality Parameters Statistics (Line Plot) ============
ax_b = fig.add_subplot(gs[0, 1])

x = np.arange(len(quality_params))

# Line plot with LARGER markers
ax_b.plot(x, min_vals, marker='o', linewidth=4, markersize=18, label='Min', 
         color='#FF6B6B', markeredgecolor='black', markeredgewidth=2.5)
ax_b.plot(x, mean_vals, marker='s', linewidth=4, markersize=18, label='Mean', 
         color='#4ECDC4', markeredgecolor='black', markeredgewidth=2.5)
ax_b.plot(x, max_vals, marker='^', linewidth=4, markersize=18, label='Max', 
         color='#95E1D3', markeredgecolor='black', markeredgewidth=2.5)

ax_b.set_ylabel('Value', fontsize=26, fontweight='bold')
ax_b.text(-0.15, 1.05, '(b)', transform=ax_b.transAxes, fontsize=32, fontweight='bold')
ax_b.set_xticks(x)
ax_b.set_xticklabels(quality_params, fontsize=20, fontweight='bold', rotation=45, ha='right')
ax_b.legend(loc='upper left', fontsize=22, framealpha=0.95, edgecolor='black', 
            fancybox=True, markerscale=1.3, handlelength=2.5)
ax_b.grid(True, alpha=0.4, linestyle='--', linewidth=1.5)

# ============ PANEL C: Product Distribution + Data Quality ============
ax_c = fig.add_subplot(gs[1, :])

colors_prod = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2']

x_pos = np.arange(len(product_names))
bars_prod = ax_c.bar(x_pos, product_values, color=colors_prod, edgecolor='black', linewidth=3)

for bar, val in zip(bars_prod, product_values):
    height = bar.get_height()
    ax_c.text(bar.get_x() + bar.get_width()/2., height + 200,
             f'{int(val):,}', ha='center', va='bottom', fontsize=22, fontweight='bold')

ax_c.set_ylabel('Number of Records', fontsize=26, fontweight='bold')
ax_c.set_xlabel('Product Type', fontsize=26, fontweight='bold')
ax_c.set_xticks(x_pos)
ax_c.set_xticklabels(product_names, fontsize=22, fontweight='bold', rotation=45, ha='right')
ax_c.grid(axis='y', alpha=0.4, linestyle='--', linewidth=1.5)
ax_c.text(-0.05, 1.05, '(c)', transform=ax_c.transAxes, fontsize=32, fontweight='bold')

# Add data quality info - MUCH LARGER FONT
quality_text = (
    f"Data Quality Summary:\n"
    f"• Valid Data: {valid_data:,} ({valid_pct:.1f}%)\n"
    f"• Missing Data: {missing_count:,} ({missing_pct:.1f}%)\n"
    f"• Anomalies: {anomalies:,} ({anomalies_pct:.1f}%)\n"
    f"• Zero Price: {zero_price:,} ({zero_price_pct:.1f}%)\n"
    f"• Zero Quantity: {zero_quantity:,} ({zero_quantity_pct:.1f}%)"
)

ax_c.text(0.98, 0.97, quality_text, transform=ax_c.transAxes,
         fontsize=20, verticalalignment='top', horizontalalignment='right',
         bbox=dict(boxstyle='round,pad=0.5', facecolor='wheat', alpha=0.95, edgecolor='black', linewidth=2.5),
         fontfamily='monospace', fontweight='bold')

# Save as PNG - 600 DPI for MDPI
plt.savefig('/home/ubuntu/Figure_1_LARGE_FONTS.png', dpi=600, bbox_inches='tight', 
            facecolor='white', edgecolor='none', format='png')

print("=" * 70)
print("✓ Figure 1 with LARGE FONTS generated!")
print("=" * 70)
print("FONT SIZE INCREASES (50-70% larger):")
print("  - Base font: 22pt (was 14pt) - 57% increase")
print("  - Axis labels: 26pt (was 16pt) - 63% increase")
print("  - Tick labels: 22pt (was 14pt) - 57% increase")
print("  - Legend: 22pt (was 14pt) - 57% increase")
print("  - Panel labels (a,b,c): 32pt (was 20pt) - 60% increase")
print("  - Bar annotations: 22pt (was 14pt) - 57% increase")
print("  - Data Quality box: 20pt (was 13pt) - 54% increase")
print("  - Figure size: 22x18 inches (was 18x14)")
print("  - Marker sizes: 18pt (was 12pt) - 50% increase")
print("  - Line widths: 4pt (was 3pt)")
print("=" * 70)
print(f"✓ PNG File: /home/ubuntu/Figure_1_LARGE_FONTS.png (600 DPI)")
print("=" * 70)

plt.close()
