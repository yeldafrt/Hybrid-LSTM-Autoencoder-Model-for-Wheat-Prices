"""
Figure 1: Dataset Overview and Data Quality Assessment (CORRECTED)
Q1 Journal Format - 600 DPI - TIFF Format - English Only

This script generates a publication-ready figure showing:
(a) Dataset Statistics
(b) Quality Parameters Statistics (Line Plot)
(c) Product Distribution with Data Quality Summary

CORRECTION: Test Set and Validation Set are both 7,604 (verified from data_split_summary.csv)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Load data
df = pd.read_excel('/home/ubuntu/upload/buğday_veri.xlsx')

# CORRECTED VALUES - Based on data_split_summary.csv
n_total = 38019
n_train = 22811  # 60%
n_val = 7604     # 20% - CORRECTED from 7603
n_test = 7604    # 20% - CORRECTED from 7605

n_features = 23  # Original features

missing_count = df['SinifAdi'].isna().sum()
missing_pct = (missing_count / n_total) * 100

anomalies = 390
anomalies_pct = (anomalies / n_total) * 100

zero_price = (df['BirimFiyati'] == 0).sum()
zero_price_pct = (zero_price / n_total) * 100

zero_quantity = (df['TahminiMiktar'] == 0).sum()
zero_quantity_pct = (zero_quantity / n_total) * 100

valid_data = n_total - missing_count - anomalies - zero_price - zero_quantity
valid_pct = (valid_data / n_total) * 100

# Set style
sns.set_style("whitegrid")
plt.rcParams['font.family'] = 'DejaVu Sans'

# Create figure
fig = plt.figure(figsize=(16, 12), dpi=600)
gs = GridSpec(2, 2, figure=fig, hspace=0.35, wspace=0.3)

# ============ PANEL A: Dataset Statistics ============
ax_a = fig.add_subplot(gs[0, 0])

stats_data = {
    'Total Records': n_total,
    'Features': n_features,
    'Training Set': n_train,
    'Validation Set': n_val,      # CORRECTED: 7604
    'Test Set': n_test,           # CORRECTED: 7604
    'Missing Data (%)': missing_pct,
    'Anomalies (%)': anomalies_pct
}

categories = list(stats_data.keys())
values = list(stats_data.values())
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']

bars = ax_a.barh(categories, values, color=colors, edgecolor='black', linewidth=2.5)

for i, (bar, val) in enumerate(zip(bars, values)):
    if i < 5:
        ax_a.text(val + 800, i, f'{int(val):,}', va='center', fontsize=12, fontweight='bold')
    else:
        ax_a.text(val + 0.25, i, f'{val:.2f}%', va='center', fontsize=12, fontweight='bold')

ax_a.set_xlabel('Value', fontsize=13, fontweight='bold')
ax_a.text(-0.15, 1.05, '(a)', transform=ax_a.transAxes, fontsize=16, fontweight='bold')
ax_a.grid(axis='x', alpha=0.4, linestyle='--', linewidth=1)
ax_a.set_xlim(0, max(values) * 1.25)

# ============ PANEL B: Quality Parameters Statistics (Line Plot) ============
ax_b = fig.add_subplot(gs[0, 1])

quality_params = ['Moisture', 'Hectolitre', 'Protein', 'Defective\nGrains', 
                  'Broken\nGrains', 'Immature\nGrains', 'Foreign\nMatter', 'Husk']
quality_cols = ['Rutubet', 'Hektolitre', 'Protein', 'KusurluTaneler', 'KirikTane', 
                'CilizBurusuk', 'YabanciMadde', 'Kavuz']

min_vals = [df[col].min() for col in quality_cols]
max_vals = [df[col].max() for col in quality_cols]
mean_vals = [df[col].mean() for col in quality_cols]

x = np.arange(len(quality_params))

# Line plot
ax_b.plot(x, min_vals, marker='o', linewidth=2.5, markersize=8, label='Min', 
         color='#FF6B6B', markeredgecolor='black', markeredgewidth=1.5)
ax_b.plot(x, mean_vals, marker='s', linewidth=2.5, markersize=8, label='Mean', 
         color='#4ECDC4', markeredgecolor='black', markeredgewidth=1.5)
ax_b.plot(x, max_vals, marker='^', linewidth=2.5, markersize=8, label='Max', 
         color='#95E1D3', markeredgecolor='black', markeredgewidth=1.5)

ax_b.set_ylabel('Value', fontsize=13, fontweight='bold')
ax_b.text(-0.15, 1.05, '(b)', transform=ax_b.transAxes, fontsize=16, fontweight='bold')
ax_b.set_xticks(x)
ax_b.set_xticklabels(quality_params, fontsize=10, fontweight='bold', rotation=45, ha='right')
ax_b.legend(loc='upper left', fontsize=11, framealpha=0.95, edgecolor='black', fancybox=True)
ax_b.grid(True, alpha=0.4, linestyle='--', linewidth=1)

# ============ PANEL C: Product Distribution + Data Quality ============
ax_c = fig.add_subplot(gs[1, :])

product_dist = df['UrunAdi'].value_counts().head(8)

# Translation mapping
translation_map = {
    'MISIR (SARI)': 'Corn (Yellow)',
    'ARPA (BEYAZ)': 'Barley (White)',
    'MAKARNALIK SERT': 'Durum Wheat',
    'ESPERİA': 'Esperia',
    'KARIŞIK KIRMIZI BUĞDAY': 'Mixed Red Wheat',
    'ÇEŞİT-1252': 'Variety-1252',
    'BAYRAKTAR': 'Bayraktar',
    'LUCİLLA': 'Lucilla'
}

# Apply translation
products_english = []
for name in product_dist.index:
    if name in translation_map:
        products_english.append(translation_map[name])
    else:
        products_english.append(name)

colors_prod = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2']

x_pos = np.arange(len(products_english))
bars_prod = ax_c.bar(x_pos, product_dist.values, color=colors_prod, edgecolor='black', linewidth=2)

for bar, val in zip(bars_prod, product_dist.values):
    height = bar.get_height()
    ax_c.text(bar.get_x() + bar.get_width()/2., height + 200,
             f'{int(val):,}', ha='center', va='bottom', fontsize=11, fontweight='bold')

ax_c.set_ylabel('Number of Records', fontsize=13, fontweight='bold')
ax_c.set_xlabel('Product Type', fontsize=13, fontweight='bold')
ax_c.set_xticks(x_pos)
ax_c.set_xticklabels(products_english, fontsize=10, fontweight='bold', rotation=45, ha='right')
ax_c.grid(axis='y', alpha=0.4, linestyle='--', linewidth=1)
ax_c.text(-0.05, 1.05, '(c)', transform=ax_c.transAxes, fontsize=16, fontweight='bold')

# Add data quality info - CORRECTED
quality_text = (
    f"Data Quality Summary:\n"
    f"• Valid Data: {valid_data:,} ({valid_pct:.1f}%)\n"
    f"• Missing Data: {missing_count:,} ({missing_pct:.1f}%)\n"
    f"• Anomalies: {anomalies:,} ({anomalies_pct:.1f}%)\n"
    f"• Zero Price: {zero_price:,} ({zero_price_pct:.1f}%)\n"
    f"• Zero Quantity: {zero_quantity:,} ({zero_quantity_pct:.1f}%)"
)

ax_c.text(0.98, 0.97, quality_text, transform=ax_c.transAxes,
         fontsize=10, verticalalignment='top', horizontalalignment='right',
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8, edgecolor='black', linewidth=1.5),
         fontfamily='monospace', fontweight='bold')

# Save as TIFF
plt.savefig('/home/ubuntu/Figure_1_Dataset_Corrected.tiff', dpi=600, bbox_inches='tight', 
            facecolor='white', edgecolor='none', format='tiff')

print("=" * 60)
print("✓ Figure 1 CORRECTED successfully!")
print("=" * 60)
print(f"✓ File: /home/ubuntu/Figure_1_Dataset_Corrected.tiff")
print(f"✓ Format: TIFF (600 DPI)")
print(f"✓ CORRECTIONS APPLIED:")
print(f"  - Training Set: {n_train:,}")
print(f"  - Validation Set: {n_val:,} (was 7,603)")
print(f"  - Test Set: {n_test:,} (was 7,605)")
print(f"  - Total: {n_train + n_val + n_test:,}")
print("=" * 60)

plt.close()
